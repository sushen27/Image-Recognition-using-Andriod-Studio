package com.example.hellothere;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Dbhandler extends SQLiteOpenHelper {
    private static final String dbname="lens.db";
    public Dbhandler(@Nullable Context context) {
        super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE information(id integer primary key autoincrement,info varchar2(100) NOT NULL,photo varchar2(25))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS information");
        onCreate(db);
    }
    public void clearDatabase()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS information");
        onCreate(db);
    }

    public String insert( String info, String f)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("info",info);
        cv.put("photo", f);
        long res = db.insert("information",null,cv);
        if(res==-1)
        {
            return "Unsuccessful";
        }
        else
            return "Successful";
    }
    public Cursor match()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * from information",null);
        return cursor;
    }
    public Cursor close_match(int k)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * from information where id="+String.valueOf(k)+"",null);
        return cursor;
    }

}
