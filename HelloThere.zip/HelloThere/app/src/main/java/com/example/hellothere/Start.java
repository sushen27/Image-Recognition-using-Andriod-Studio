package com.example.hellothere;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Start extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
    }

    public void ins(View view) {
        startActivity(new Intent(this,MainActivity.class));
    }

    public void retrieve(View view) {
        startActivity(new Intent(this,search.class));
    }

    public void clear(View view) {
        Dbhandler bd = new Dbhandler(this);
        bd.clearDatabase();
        Toast.makeText(this, "Successfully cleared Database", Toast.LENGTH_SHORT).show();
    }

    public void instruct(View view) {
        startActivity(new Intent(this,Instruction.class));
    }
}