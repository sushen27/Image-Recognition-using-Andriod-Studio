package com.example.hellothere;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class search extends AppCompatActivity {
    public static final int camer_permission_code = 101;
    public static final int camer_request_code = 102;
    private static final int REQUEST_IMAGE_CAPTURE = 300;
    ImageView selectedImage;
    Button search;
    String currentPhotoPath;
    String pic;
    TextView info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        info=findViewById(R.id.textView);
        selectedImage = findViewById(R.id.imageView2);
        search=findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View view) {
                                          askCamerPermission();
                                      }
                                  }
        );
    }
    private void askCamerPermission() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.CAMERA}, camer_permission_code);
        }
        else
        {
            dispatchTakePictureIntent();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == camer_permission_code) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent();
            }
        } else {
            Toast.makeText(this, "We need the permission to use this App", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==camer_request_code)
            if(resultCode== Activity.RESULT_OK)
            {
                Toast.makeText(this, "Please wait as it would take time to fetch the data", Toast.LENGTH_LONG).show();
                Bitmap image1 = BitmapFactory.decodeFile(currentPhotoPath);
                Bitmap image2;
                boolean equals=true;
                boolean flag;
                double max=0;
                int key=0,k=1;
                //selectedImage.setImageURI(Uri.fromFile(f));
                Dbhandler db = new Dbhandler(this);
                Cursor crs=db.match();
                crs.moveToFirst();
                while (crs.moveToNext())
                {
                    k++;
                    flag=true;
                    equals=true;
                    pic = crs.getString(2);
                    File f = new File(pic);
                    image2 = BitmapFactory.decodeFile(pic);
                    Boolean result=image1.sameAs(image2);
                    double equal=0,total=0;
                    if (image1.getByteCount() == image2.getByteCount())
                    {
                        for (int x = 0; x < image1.getWidth(); ++x)
                        {
                            for (int y = 0; y < image2.getHeight(); ++y)
                            {
                                if (image1.getPixel(x, y) != image2.getPixel(x, y))
                                {
                                    equals = false;
                                    flag = false;
                                   // break;
                                }
                                else
                                {
                                    equal++;
                                }
                                total++;
                            }
                           /* if (!flag)
                            {
                                break;
                            }*/
                        }
                    }
                    else
                    {
                        equals = false;
                    }
                    equal = (equal / total)*100;
                    if(max<equal)
                    {
                        max=equal;
                        key=k;
                    }
                   //
                    if(result==true || equals==true )
                    {
                        Toast.makeText(this, "Found" , Toast.LENGTH_SHORT).show();
                        selectedImage.setImageURI(Uri.fromFile(f));
                        info.setText(crs.getString(1));
                        Toast.makeText(this, String.valueOf(equal), Toast.LENGTH_SHORT).show();
                        break;
                    }

                }
                //Toast.makeText(this, String.valueOf(max), Toast.LENGTH_SHORT).show();
                if(equals == false & max>0)
                {
                    Cursor cursor = db.close_match(key);
                    while (cursor.moveToNext())
                    {
                        selectedImage.setImageURI(Uri.parse(cursor.getString(2)));
                        info.setText(cursor.getString(1));
                        Toast.makeText(this, "This image in database closely resembles the intended image \nwith resemblance Quotient of "+String.valueOf(max), Toast.LENGTH_LONG).show();
                        break;
                    }
                }
                else
                {
                    Toast.makeText(this, "Sorry the image searched is not available in the database", Toast.LENGTH_SHORT).show();
                }

            }


      /*  Blob b = (Blob) selectedImage.getDrawable();
        Toast.makeText(this, b.toString(), Toast.LENGTH_SHORT).show();*/
    }
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }
    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                // ...
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, camer_request_code);
            }
        }
    }

}